/*
 
 Given 2 sorted integer arrays
 a = [1, 5, 10, 11]
 b = [2, 3, 6, 7, 11, 12]
 
 merge them into one array which is also sorted
 
 output = [1, 2, 3, 5, 6, 7, 10, 11, 11, 12]
 
 */

//Merve Kavaklioglu 19 March 2020

import Foundation

var ar1 = [1,2,3,5,8,9,9,9,10,15,16,18] // 12 elements
var ar2 = [4,6,7,8,9,9,10,13,17,19] // 10 elements

func sortTwoArrays(a1:[Int],a2:[Int]) ->[Int] {
    var indexOfa1:Int = 0
    var indexOfa2:Int = 0
    
    var sortedArray = [Int]()//empty element
    
    while (indexOfa2<a2.count && indexOfa1<a1.count) {
        if a1[indexOfa1]<a2[indexOfa2] {
            sortedArray.append(a1[indexOfa1])
            indexOfa1 += 1
        }
        else if a1[indexOfa1]>a2[indexOfa2] {
            sortedArray.append(a2[indexOfa2])
            indexOfa2 += 1
        }
        else {
            sortedArray.append(a1[indexOfa1])
            sortedArray.append(a2[indexOfa2])
            indexOfa1 += 1
            indexOfa2 += 1
        }
    }
    if indexOfa2<ar2.count {
        for i in indexOfa2...ar2.count-1 {
            sortedArray.append(a2[i])
        }
    }
    if indexOfa1<ar1.count {
        for i in indexOfa1...ar1.count-1 {
            sortedArray.append(a1[i])
        }
    }
    return sortedArray
}
print(sortTwoArrays(a1: ar1, a2: ar2))

