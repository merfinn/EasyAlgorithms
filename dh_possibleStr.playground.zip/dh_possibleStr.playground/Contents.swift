import UIKit

var str = "Hello, playground"

//1- real, 2 - possible
//apple -> a10le
//apple -> a333e
//ap333 -> apple

func compare(real:String , possible:String) -> Bool {
    var number1 = 0
    if real == possible { //already the same string
        return true
    }
    else {
        for (i,char) in possible.enumerated() { //iterate through the possible string
            if char.isNumber { //Int(String(char)) != nil //catch the number inside
                number1 = Int(String(char))!-1 //the number holds already one place so we must omit it.
                if possible.count + number1 != real.count { //the strings have different lenghts
                    return false
                }
            } else if char != Array(real)[i+number1]  { //if it is not the number it should be the equal characters
                return false
            }
        }
        return true //at the end all characters , stepping the number, are equal
    }
}

compare(real: "apple", possible: "1pple")

//ale =? ale
