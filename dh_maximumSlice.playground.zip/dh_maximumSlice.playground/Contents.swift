import UIKit

public func solution(_ A : [Int]) -> Int {
    //brute force
    var solution = 0;
    
    for i in 0 ..< A.count {
        var number1 = 0
        var number2 = 0
        var isAssigned1 = false
        var isAssigned2 = false
        
        var max = 0
        for j in i...A.count-1 {
            if isAssigned1 == false {
                number1 = A[j]
                isAssigned1 = true
                max = max + 1
            }
            else if isAssigned1 == true && A[j] == number1 {
                max = max + 1
            }
            else if isAssigned2 == false {
                number2 = A[j]
                isAssigned2 = true
                max = max + 1
            }
            else if isAssigned2 == true && A[j] == number2 {
                max = max + 1
            }
            else {
                break
            }
        }
        solution = solution > max ? solution:max
    }
    return solution
}
var a = [1,1,1,2,1,1,2,1,2,3,1,3,3,1,2,1,1,1,3,3,1,1,1,3,1,4]
print(solution(a))
