//find palindrome integers
func isPalindrome(a:Int)->Bool {
    var ladder = 1
    var number = a
    //find the biggest value of the number.
    while number/ladder>1 {
        ladder *= 10
    }
    while number != 0 {
        let beginning = number / ladder;
        let end = number % 10;
        //return if not same
        if beginning != end {
            return false;
        }
        //reform the number - omit first and last
        number = (number % ladder) / 10;
        // Reducing divisor by a factor
        // of 2 as 2 digits are dropped
        ladder = ladder / 100;
    }
    return true;
}
print(isPalindrome(a: 1453))
